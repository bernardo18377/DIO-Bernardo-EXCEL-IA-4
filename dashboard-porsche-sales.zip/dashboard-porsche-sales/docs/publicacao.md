# Publicação

## Situação desta entrega

O projeto foi desenvolvido no checkout de `bernardo18377/DIO-Bernardo-EXCEL-IA-4`. Esse é o repositório de trabalho existente, não uma publicação confirmada do novo projeto.

O nome solicitado para o novo repositório público é `dashboard-porsche-sales`. Nenhum repositório novo foi criado e nenhum site foi declarado publicado: as consultas `gh api user` e `gh api repos/bernardo18377/dashboard-porsche-sales` receberam `Forbidden`. Uma consulta HTTPS independente a `https://api.github.com/` identificou `Tunnel connection failed: 403 Forbidden`. Portanto, nem a identidade autenticada nem a disponibilidade do nome puderam ser confirmadas pela API. O acesso de leitura Git ao repositório existente funciona e não comprova permissão de criação ou de publicação.

`gh auth status` também não conseguiu validar a autenticação presente. Isso não justifica substituir a autenticação da plataforma: primeiro é necessário resolver o bloqueio de rede e repetir a operação real. Nenhum valor de credencial foi lido ou incluído no projeto.

Foi salvo um rascunho de configuração do ambiente acrescentando `api.github.com`, `docs.github.com` e `bernardo18377.github.io` aos domínios personalizados permitidos, preservando os presets existentes. O salvamento não alterou a rede da máquina em execução. Para retomar neste ambiente, revise e salve essas mudanças nas configurações e publique a configuração do ambiente. Isso é diferente de publicar a dashboard. Depois, repita a consulta de identidade; a publicação ainda depende das permissões reais da conta.

## Roteiro para publicar o projeto pronto

Use um ambiente com acesso autorizado à sua conta pessoal. Não envie tokens ou senhas no chat. Antes de publicar, execute os testes descritos no README e confira os arquivos com `git status --short` e `git diff --cached --name-only`. A planilha original deve continuar fora do Git.

1. Confirme a conta com `gh api user --jq '{login: .login, type: .type}'`. O destino esperado neste trabalho é a conta pessoal `bernardo18377`; se outra conta aparecer, corrija a sessão antes de criar o repositório. Falha de rede ou de autenticação não comprova que o nome esteja disponível.
2. Verifique na conta correta se `dashboard-porsche-sales` já existe. Não sobrescreva um projeto existente. Se houver conflito, inspecione-o antes de escolher outro nome.
3. Crie um **novo repositório público** com esse nome, sem README adicional. Para publicar a partir do ZIP, extraia os arquivos em uma pasta nova e execute nela:

```sh
git init -b main
git add .
git diff --cached --name-only
git commit -m "Cria dashboard Porsche Sales com dados e testes"
gh repo create bernardo18377/dashboard-porsche-sales --public --source=. --remote=origin --push
```

Os comandos acima são o roteiro para execução externa; não foram executados nesta entrega. O ZIP não contém `.git`, credenciais nem a planilha original. Se preferir usar o checkout de trabalho existente, preserve seu `origin`: crie o repositório pela interface, adicione-o como um segundo remoto e envie o commit revisado para a branch `main` do novo destino.

4. No novo repositório, abra **Settings → Pages → Build and deployment → Source: Deploy from a branch**. Selecione **main** e **/(root)** e salve. Não é necessário build, servidor de aplicação ou dependências para servir o HTML.
5. Acompanhe o deploy e copie a URL que o próprio Pages informar. Verifique que o repositório está público e pertence à conta correta. Abra o site, compare os quatro indicadores com a validação local e aplique pelo menos um filtro.
6. Só depois de confirmar o endereço ativo, acrescente ao README as duas URLs reais: a do repositório para submissão à DIO e a da dashboard para visualização. Envie essa atualização ao novo repositório.

A documentação oficial indicada no pedido é [Configuring a publishing source for your GitHub Pages site](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site). A abertura dessa página neste ambiente também foi bloqueada pelo túnel com HTTP 403; ela é citada como referência fornecida, não como consulta realizada com sucesso.
